# Copyright (C) 2016 Li Cheng at Beijing University of Posts
# and Telecommunications. www.muzixing.com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# conding=utf-8

import sys
sys.path.append("/home/liyan/ryu")
import socket
import json
import networkx as nx
from ryu import cfg
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER
from ryu.controller.handler import CONFIG_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib import hub



CONF = cfg.CONF


class Controller(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(Controller, self).__init__(*args, **kwargs)
        self.name = "Controller_multi"
        self.datapaths = {}
        self.graph = nx.DiGraph()
        self.topo = nx.DiGraph()

        self.status = False
        self.client_id = 1
        self.send_queue = hub.Queue(16)
        self.socket = socket.socket()
        self.start_serve('127.0.0.1', 8888)
        self.time = 0
	self.topology = []
	self.topo_list = [] 

	
    def start_serve(self, server_addr, server_port):
        self.socket.connect((server_addr, server_port))
        self.status = True
        hub.spawn(self._rece_loop)
        hub.spawn(self._send_loop)

    def _send_loop(self):
        while self.status:
            message = self.send_queue.get()
            message += '\n'
            self.socket.sendall(message)

    def _rece_loop(self):
        while self.status:
            message = self.socket.recv(128)
            if len(message) == 0:
                self.logger.info('connection fail, close')
                self.status = False
                break
            data = message.split("\n")
            for temp in data:
                #print(temp)
                msg = json.loads(temp)
                if msg['cmd'] == 'set_id':
                    self.client_id = msg['client_id']
		if msg['cmd'] == 'set_topo':
		    self.topology = msg['topo']
    def send(self, msg):
        if self.send_queue != None:
            self.send_queue.put(msg)

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def _switch_features_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath
        dpid = datapath.id	
        
        if datapath.id not in self.datapaths:
            self.logger.info("switch:%s connected", dpid)
            self.datapaths[dpid] = datapath
            self.graph.add_node(dpid - 17592186044416)
	

    @set_ev_cls(ofp_event.EventOFPNeighboursReply, MAIN_DISPATCHER)
    def neighbours_handler(self, ev):
        """
        Handle OFP_NEIGHBOURS_REPLY from datapath.
        """
        print 'edges: ', self.graph.edges(data=True)
        datapath = ev.msg.datapath
        msg = ev.msg

        assert datapath.id in self.datapaths

        neighbours = self.graph[datapath.id - 17592186044416].keys()

        # update links related to datapath.id
        # 1.remove edges related to datapath.id
        for n in neighbours:
            self.graph.remove_edge(datapath.id - 17592186044416, n)
            
        # 2.add edges according to msg.data
        index = 0
        for neighbour in msg.neighbours:
            if neighbour !=0:
		
                self.graph.add_edge(datapath.id - 17592186044416, neighbour, rssi=(msg.rssi[index]))
                self.add_topo(datapath.id - 17592186044416, neighbour, 0-msg.rssi[index])
            index += 1
        
        self.get_whole_graph()

    def get_whole_graph(self):	
        self.get_topo()
        print(self.topology)
	l = len(self.topology)

	t = 0
	self.topo_list *= 0
	for i in range(0, l):
		
		self.topo_list.append(self.topology[i][t][t])
		self.topo_list.append(self.topology[i][t][t+1])
		self.topo_list.append(self.topology[i][t+1])
        #print(self.topo_list)
	
	a = len(self.topo_list)
	for i in range(0, a, 3):
		self.topo.add_edge(self.topo_list[i], self.topo_list[i+1],  rssi = 0 - self.topo_list[i+2])
	#print(self.topo.edges())
	return self.topo
        

    def get_graph(self):
        return self.graph

    def add_topo(self, src_dpid, dst_dpid, rssi):
        msg = json.dumps({
            'cmd': 'add_topo',
            'src_dpid': src_dpid,
            'dst_dpid': dst_dpid,
            'rssi': rssi
        })
        self.send(msg)

    def get_topo(self):
        msg = json.dumps({
            'cmd': 'get_topo'
        })
        self.send(msg)
