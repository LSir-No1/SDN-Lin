# Copyright (C) 2016 Li Cheng at Beijing University of Posts
# and Telecommunications. www.muzixing.com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# conding=utf-8
import networkx as nx

from ryu import cfg
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER
from ryu.controller.handler import MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.lib import hub
from ryu.ofproto import ofproto_v1_3

CONF = cfg.CONF


class SetTxpower(app_manager.RyuApp):

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(SetTxpower, self).__init__(*args, **kwargs)
        self.topology_api_app = self
        self.name = "SetTxpower"
        self.datapaths = {}


        # Start a green thread to discover network resource.
        self.neighbour_thread = hub.spawn(self._setTxpower)

    def _setTxpower(self):
        # self.logger.info("The edges of Graph:", self.graph.edges)
        while True:
            for dp in self.datapaths.values():
                self._send_SetTxpower(dp)
            hub.sleep(5)   # The sending interval is 5s

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """
            Initial operation, find all connected datapaths.
        """
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        msg = ev.msg
        if datapath.id not in self.datapaths:
            self.logger.info("switch:%s connected", datapath.id)
            self.datapaths[datapath.id] = datapath


    def _send_SetTxpower(self, datapath):
        """
        Send neighbours_request message to datapath

        """
        self.logger.info('send SetTxpower: %016x', datapath.id)
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        # OFPSetTxpower(datapath, txpower, port)
        req = parser.OFPSetTxpower(datapath,20,1)
        datapath.send_msg(req)
        req = parser.OFPSetTxpower(datapath,14,2)
        datapath.send_msg(req)


