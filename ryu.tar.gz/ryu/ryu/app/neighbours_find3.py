# Copyright (C) 2016 Li Cheng at Beijing University of Posts
# and Telecommunications. www.muzixing.com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# conding=utf-8
import networkx as nx
from ryu import cfg
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, DEAD_DISPATCHER
from ryu.controller.handler import CONFIG_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib import hub
from threading import Lock
import time

lock = Lock()
CONF = cfg.CONF

class NeighboursFind(app_manager.RyuApp):

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(NeighboursFind, self).__init__(*args, **kwargs)
        self.topology_api_app = self
        self.name = "NeighboursFind"
        self.datapaths = {}
        self.last_reply_timestamp = {}
        self.graph1 = nx.DiGraph()
        self.graph2 = nx.DiGraph()
        self.remove_overtime_edges_thread = hub.spawn(self._remove_overtime_edges)

    def _remove_overtime_edges(self):
        while True:
            currtime = time.time()
            for key in self.last_reply_timestamp.keys():
                if(currtime - self.last_reply_timestamp[key] > 8):
                    lock.acquire()
                    neighbours = self.graph1[key].keys()

                    for n in neighbours:
                        self.graph1.remove_edge(key, n)
                    neighbours = self.graph2[key].keys()
                    for n in neighbours:
                        self.graph2.remove_edge(key, n)
                    del self.last_reply_timestamp[key]
                    lock.release()
            hub.sleep(2)


    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """
            Initial operation, find all connected datapaths.
        """
        datapath = ev.msg.datapath

        if datapath.id not in self.datapaths:
            self.logger.info("switch:%s connected", datapath.id)
            self.datapaths[datapath.id] = datapath
            self.graph1.add_node(datapath.id - 17592186044416)
            self.graph2.add_node(datapath.id - 17592186044416)

    @set_ev_cls(ofp_event.EventOFPNeighboursReply, MAIN_DISPATCHER)
    def neighbours_handler(self, ev):
        """
        Handle OFP_NEIGHBOURS_REPLY from datapath.
        """
        print "edges in graph-1: ", self.graph1.edges(data=True)
        print "edges in graph-2: ", self.graph2.edges(data=True)

        datapath = ev.msg.datapath
        msg = ev.msg
        assert datapath.id in self.datapaths
        # print "ap%d's neighbours: " % (datapath.id - 743008370688), msg.data

        # update links related to datapath.id
        lock.acquire()
        self.last_reply_timestamp[datapath.id - 17592186044416] = time.time()
        lock.release()
        # 1.remove edges related to datapath.id
        neighbours = self.graph1[datapath.id - 17592186044416].keys()
        for n in neighbours:
            self.graph1.remove_edge(datapath.id - 17592186044416, n)

        neighbours = self.graph2[datapath.id - 17592186044416].keys()
        for n in neighbours:
            self.graph2.remove_edge(datapath.id - 17592186044416, n)

        # 2.add edges according to msg.data
        index = 0
        for i in range(10):
            if msg.neighbours[i] != 0 and msg.neighbours[i] + 17592186044416 in self.datapaths:
                # self.graph.add_edge(datapath.id, neighbour+743008370688)
                if i < 5:
                    self.graph1.add_edge(datapath.id - 17592186044416, msg.neighbours[i], rssi=(0-msg.rssi[index]))
                else:
                    self.graph2.add_edge(datapath.id - 17592186044416, msg.neighbours[i], rssi=(0 - msg.rssi[index]))

            index += 1


    def get_graph(self):
        return self.graph1, self.graph2
