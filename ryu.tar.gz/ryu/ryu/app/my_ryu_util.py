from collections import defaultdict
from ryu.lib import dpid
from threading import Thread, Lock
from time import sleep
import json
import re
import os

MAX = 1024
DPID = 743008370689
route_table = defaultdict(dict)

class Node:
    def __init__(self, position=None, range=-1.0):
        if position is None:
            position = [0.0, 0.0, 0.0]
        self.x = position[0]
        self.y = position[1]
        self.z = position[2]
        self.range = range

    def isInRange(self, node):
        """
        Determine if the target node is in the range of this node
        :param node: the target node
        :return: True or False
        """
        if self.getDistance(node) <= self.range:
            return True
        return False

    def getDistance(self, node):
        """
        Calculate the distance between this node and the target node
        :param node: target node
        :return: (float) distance between this node and the target node
        """
        distance = ((self.x - node.x)**2 + (self.y - node.y)**2 + (self.z - node.z)**2)**0.5
        return distance


class Graph:
    def __init__(self, node_list=None):
        self.nodes = []
        self.ADJ = []

        if node_list:
            self.nodes = node_list

            # Init the Adjacency matrix
            for i in range(len(node_list)):
                self.ADJ.append([])
                for j in range(len(node_list)):
                    self.ADJ[i].append(MAX)
            for i in range(len(node_list)):
                self.ADJ[i][i] = 0

        
        self.createADJ()

    def createADJ(self):
        NODES = len(self.nodes)
        if NODES == 0:
            return
        
        for i in range(NODES-1):
            for j in range(i+1, NODES):
                if(self.nodes[i].isInRange(self.nodes[j]) and
                self.nodes[i].isInRange(self.nodes[j])):
                    self.ADJ[i][j] = 1
                    self.ADJ[j][i] = 1

    def FloydAlgrithm(self):
        weight = self.ADJ[:]
        length = len(weight)
        path = []
        for i in range(length):
            path.append([])
            for j in range(length):
                path[i].append(j)
        for m in range(length):
            for i in range(length):
                for j in range(length):
                    if (weight[i][m] + weight[m][j] < weight[i][j]) and i != j:
                        weight[i][j] = weight[i][m] + weight[m][j]
                        path[i][j] = m

        return weight, path

    def PrintADJ(self):
        for lst in self.ADJ:
            for i in lst:
                print i, ' ',
            print ""


class NodeWithMac:
    def __init__(self, filename):
        with open(filename, 'r') as load_f:
            link_dict = json.load(load_f)
        self.mac = link_dict["MAC"]
        self.neighbour = link_dict["Neighbour"]


class LinkGraph:
    def __init__(self, linkfiledir='/home/sdn/mininet-wifi/examples/neighbour'):
        self.nodes = []
        self.ADJ = []
        file_list = os.listdir(linkfiledir)
        file_list.sort()
        for f in file_list:
            self.nodes.append(NodeWithMac(linkfiledir+'/'+f))

        for i in range(len(self.nodes)):
            self.ADJ.append([])
            for j in range(len(self.nodes)):
                self.ADJ[i].append(MAX)
        for i in range(len(self.nodes)):
            self.ADJ[i][i] = 0
        self.createADJ()

    def createADJ(self):
        NODES = len(self.nodes)
        if NODES == 0:
            return

        for i in range(NODES):
            for j in range(NODES):
                if i == j:
                    continue
                if self.nodes[j].mac in self.nodes[i].neighbour:
                    self.ADJ[i][j] = 1

    def FloydAlgrithm(self):
        weight = self.ADJ[:]
        length = len(weight)
        path = []
        for i in range(length):
            path.append([])
            for j in range(length):
                path[i].append(j)
        for m in range(length):
            for i in range(length):
                for j in range(length):
                    if (weight[i][m] + weight[m][j] < weight[i][j]) and i != j:
                        weight[i][j] = weight[i][m] + weight[m][j]
                        path[i][j] = m

        return weight, path

    def PrintADJ(self):
        for lst in self.ADJ:
            for i in lst:
                print i, ' ',
            print ""



def loadPositionFile(filename='/home/sdn/mininet-wifi/examples/test_position.json'):
    with open(filename, 'r') as load_f:
        position_dict = json.load(load_f)

    return createTopology(position_dict)

def createTopology(position_dict):
    # the element of node_list is Node
    node_list = []
    # the number of nodes is NODES
    NODES = len(position_dict)
    dpid_from_mininet_wifi = []
    # Init the node_list
    for i in range(1,len(position_dict)+1):
        dpid_from_mininet_wifi.append('10000000000%d' % i)
    for key in dpid_from_mininet_wifi:
        node_list.append(Node(position_dict[key]['position'], float(position_dict[key]['range'])))

    # The topology 
    topology = Graph(node_list)
    return topology
    
    
def generateRouteTable_core(graph):
    # Get the path table
    path = graph.FloydAlgrithm()[1]
    print path
    length = len(path)
    global route_table
    dpid_to_str = [(743008370689,'02:00:00:00:00:00'), (743008370690,'02:00:00:00:02:00'),
                   (743008370691,'02:00:00:00:04:00'), (743008370692,'02:00:00:00:06:00'),
                   (743008370693,'02:00:00:00:08:00'), (743008370694,'02:00:00:00:0a:00'),
                   (743008370695,'02:00:00:00:0c:00'), (743008370696,'02:00:00:00:0e:00'),
                   (743008370697,'02:00:00:00:10:00'), (743008370698,'02:00:00:00:12:00')]
    for i in range(length):
        for j in range(length):
            if i != j:
                src = dpid.dpid_to_str((i+1))[4:]
                src = ':'.join(re.findall('.{2}', src))
                dst = dpid.dpid_to_str((j+1))[4:]
                dst = ':'.join(re.findall('.{2}', dst))
                next = path[i][j]
                curr = i
                while(True):
                    route_table[dpid_to_str[curr][0]][(src,dst)] = dpid_to_str[next][1]
                    if curr == j:
                        break
                    curr = next
                    next = path[curr][j]
    print route_table


def generateRouteTable():
    lock = Lock()
    while True:
        try:
            lock.acquire()
            topology = loadPositionFile()
            lock.release()
            generateRouteTable_core(topology)
        except IOError:
            lock.release()
            print "No such file"
            sleep(2)
        else:
            print "success"
            break

def generateRouteTable_withLinkGraph():
    lock = Lock()
    while True:
        try:
            lock.acquire()
            topology = LinkGraph()
            lock.release()
            generateRouteTable_core(topology)
        except IOError:
            lock.release()
            print "No such file"
            sleep(2)
        else:
            print "success"
            break


def getRouteTable():
    t = Thread(target=generateRouteTable)
    t.start()

def getRouteTable_withLinkGraph():
    t = Thread(target=generateRouteTable_withLinkGraph)
    t.start()

if __name__ == '__main__':
    topology = loadPositionFile()
    topology.PrintADJ()
    print ""
    # generateRouteTable_core(topology)
    graph = LinkGraph()
    graph.PrintADJ()

    if topology.ADJ == graph.ADJ:
        print True
    else:
        print False
