# Copyright (C) 2016 Li Cheng at Beijing University of Posts
# and Telecommunications. www.muzixing.com
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# conding=utf-8
import logging
import struct
import copy
import networkx as nx
from operator import attrgetter
from ryu import cfg
from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import MAIN_DISPATCHER, DEAD_DISPATCHER
from ryu.controller.handler import CONFIG_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet
from ryu.lib.packet import ipv4
from ryu.lib.packet import arp
from ryu.lib import hub

from ryu.topology import event, switches
from ryu.topology.api import get_switch, get_link


CONF = cfg.CONF


class NeighboursFind(app_manager.RyuApp):

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(NeighboursFind, self).__init__(*args, **kwargs)
        self.topology_api_app = self
        self.name = "NeighboursFind"
        self.datapaths = {}
        self.graph = nx.DiGraph()

        # Start a green thread to discover network resource.
        self.neighbour_thread = hub.spawn(self._find_neighbours)

    def _find_neighbours(self):
        # self.logger.info("The edges of Graph:", self.graph.edges)
        while True:
            for dp in self.datapaths.values():
                self._request_neighbours(dp)
            hub.sleep(5)   # The sending interval is 5s

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        """
            Initial operation, find all connected datapaths.
        """
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        msg = ev.msg
        if datapath.id not in self.datapaths:
            self.logger.info("switch:%s connected", datapath.id)
            self.datapaths[datapath.id] = datapath
            self.graph.add_node(datapath.id - 17592186044416)

    def _request_neighbours(self, datapath):
        """
        Send neighbours_request message to datapath

        """
        self.logger.debug('send neighbours request: %016x', datapath.id)
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        req = parser.OFPNeighboursRequest(datapath)
        datapath.send_msg(req)

    @set_ev_cls(ofp_event.EventOFPNeighboursReply, MAIN_DISPATCHER)
    def neighbours_handler(self, ev):
        """
        Handle OFP_NEIGHBOURS_REPLY from datapath.
        """
        print "edges: ", self.graph.edges(data=True)
        # print self.graph.nodes
        datapath = ev.msg.datapath
        msg = ev.msg
        assert datapath.id in self.datapaths
        # print "ap%d's neighbours: " % (datapath.id - 743008370688), msg.data


        # update links related to datapath.id
        # 1.remove edges related to datapath.id
        neighbours = self.graph[datapath.id - 17592186044416].keys()
        for n in neighbours:
            self.graph.remove_edge(datapath.id - 17592186044416, n)

        # 2.add edges according to msg.data
        index = 0
        for neighbour in msg.neighbours:
            if neighbour != 0 and neighbour + 17592186044416 in self.datapaths:
                # self.graph.add_edge(datapath.id, neighbour+743008370688)
                self.graph.add_edge(datapath.id - 17592186044416, neighbour, rssi=(0-msg.rssi[index]))

            index += 1

    def get_graph(self):
        return self.graph
