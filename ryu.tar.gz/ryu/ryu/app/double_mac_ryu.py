# Copyright (C) 2011 Nippon Telegraph and Telephone Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from ryu.base import app_manager
from ryu.controller import ofp_event
from ryu.controller.handler import CONFIG_DISPATCHER, MAIN_DISPATCHER
from ryu.controller.handler import set_ev_cls
from ryu.ofproto import ofproto_v1_3
from ryu.lib.packet import packet
from ryu.lib.packet import ethernet,mpls, arp, ipv4
from ryu.lib.packet import ether_types
from collections import defaultdict

dpid_to_str = {743008370689:'02:00:00:00:00:00',
               743008370690:'02:00:00:00:02:00',
               743008370691:'02:00:00:00:04:00',}

dst_to_isid = {('00:00:00:00:00:02','00:00:00:00:00:01'):1,
               ('00:00:00:00:00:01','00:00:00:00:00:02'):2,
               ('00:00:00:00:00:01','00:00:00:00:00:03'):3,
               ('00:00:00:00:00:03','00:00:00:00:00:01'):4,
               ('00:00:00:00:00:03','00:00:00:00:00:02'):5,
               ('00:00:00:00:00:02','00:00:00:00:00:03'):6,}

# ap1:1,4----ap2-ap1;ap3-ap1
# ap2:2,5----ap1-ap2;ap3-ap2
# ap3:3,6----ap1-ap3;ap2-ap3

# dpid_to_isid = {743008370689:1,
#                 743008370690:2,
#                 743008370691:3,}

str_to_hostmac = {'02:00:00:00:00:00':'00:00:00:00:00:01',
                  '02:00:00:00:02:00':'00:00:00:00:00:02',
                  '02:00:00:00:04:00':'00:00:00:00:00:03',}
# route_table is a dictionary in the form of {dpid:{(src,dst):next_hop, ...},...}
route_table = {743008370689:
                   {('00:00:00:00:00:01','00:00:00:00:00:02'):'02:00:00:00:02:00',
                    ('00:00:00:00:00:01','00:00:00:00:00:03'):'02:00:00:00:02:00',
                    ('00:00:00:00:00:02','00:00:00:00:00:01'):'02:00:00:00:00:00',
                    ('00:00:00:00:00:03','00:00:00:00:00:01'):'02:00:00:00:00:00'},
               743008370690:
                   {('00:00:00:00:00:01', '00:00:00:00:00:02'): '02:00:00:00:02:00',
                    ('00:00:00:00:00:01', '00:00:00:00:00:03'): '02:00:00:00:04:00',
                    ('00:00:00:00:00:02', '00:00:00:00:00:01'): '02:00:00:00:00:00',
                    ('00:00:00:00:00:02', '00:00:00:00:00:03'): '02:00:00:00:04:00',
                    ('00:00:00:00:00:03', '00:00:00:00:00:01'): '02:00:00:00:00:00',
                    ('00:00:00:00:00:03', '00:00:00:00:00:02'): '02:00:00:00:02:00'},
               743008370691:
                   {('00:00:00:00:00:01', '00:00:00:00:00:03'): '02:00:00:00:04:00',
                    ('00:00:00:00:00:02', '00:00:00:00:00:03'): '02:00:00:00:04:00',
                    ('00:00:00:00:00:03', '00:00:00:00:00:01'): '02:00:00:00:02:00',
                    ('00:00:00:00:00:03', '00:00:00:00:00:02'): '02:00:00:00:02:00'}
               }
NODES = 3


class SimpleSwitch13(app_manager.RyuApp):
    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    def __init__(self, *args, **kwargs):
        super(SimpleSwitch13, self).__init__(*args, **kwargs)
        self.mac_to_port = {}

    @set_ev_cls(ofp_event.EventOFPSwitchFeatures, CONFIG_DISPATCHER)
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        # install table-miss flow entry
        #
        # We specify NO BUFFER to max_len of the output action due to
        # OVS bug. At this moment, if we specify a lesser number, e.g.,
        # 128, OVS will send Packet-In with invalid buffer_id and
        # truncated packet data. In that case, we cannot output packets
        # correctly.  The bug has been fixed in OVS v2.1.0.
        match = parser.OFPMatch()
        actions = [parser.OFPActionOutput(ofproto.OFPP_CONTROLLER,
                                          ofproto.OFPCML_NO_BUFFER)]
        self.add_flow(datapath, 0, match, actions)

    def add_flow(self, datapath, priority, match, actions, table_id=0, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS,actions)]

        #print 'inst:%s ' % inst
        if buffer_id:
            mod = parser.OFPFlowMod(datapath=datapath, buffer_id=buffer_id,
                                    priority=priority, match=match, table_id=table_id,
                                    instructions=inst)
        #    print "can't find isid1"
        else:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                    match=match, table_id=table_id, instructions=inst)
        datapath.send_msg(mod)

    def add_flow1(self, datapath, priority, match, actions, table_id=0, buffer_id=None):
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser

        inst = [parser.OFPInstructionActions(ofproto.OFPIT_APPLY_ACTIONS,actions),
                parser.OFPInstructionGotoTable(table_id=1)]

        #print 'inst:%s ' % inst
        if buffer_id:
            mod = parser.OFPFlowMod(datapath=datapath, buffer_id=buffer_id,
                                    priority=priority, match=match, table_id=table_id,
                                    instructions=inst)
        #    print "can't find isid1"
        else:
            mod = parser.OFPFlowMod(datapath=datapath, priority=priority,
                                    match=match, table_id=table_id, instructions=inst)
        datapath.send_msg(mod)

      #  print "can't find isid2"

    @set_ev_cls(ofp_event.EventOFPPacketIn, MAIN_DISPATCHER)
    def _packet_in_handler(self, ev):
        # If you hit this you might want to increase
        # the "miss_send_length" of your switch
        if ev.msg.msg_len < ev.msg.total_len:
            self.logger.debug("packet truncated: only %s of %s bytes",
                              ev.msg.msg_len, ev.msg.total_len)
        msg = ev.msg
        datapath = msg.datapath
        ofproto = datapath.ofproto
        parser = datapath.ofproto_parser
        in_port = msg.match['in_port']

        pkt = packet.Packet(msg.data)
        eth1 = pkt.get_protocols(ethernet.ethernet)[0]
        eth2 = None
        pop_src = pop_dst = None

        if len(pkt.get_protocols(ethernet.ethernet(ethertype=0x88E7))) == 2:
            eth2 = pkt.get_protocols(ethernet.ethernet(ethertype=0x88E7))[1]

        if eth1.ethertype == ether_types.ETH_TYPE_LLDP:
            # ignore lldp packet
            return
        if eth1.ethertype ==  ether_types.ETH_TYPE_IPV6:
            # ignore IPV6 packet
            return
        dst = None
        src = None
        next_dst = None

        if eth2:
            src = eth2.src
            dst = eth2.dst
            next_dst = eth1.dst
        else:
            src = eth1.src
            dst = eth1.dst
            next_dst = eth1.dst
        # else:
        #     print "error: can't get mpls ethernet address"
        # if eth2:
        #     print src, dst, eth1.dst
        # else:
        #     print src, dst, None

        dpid = datapath.id
        self.mac_to_port.setdefault(dpid, {})

        self.logger.info("packet in %s %s %s %s", dpid, src, dst, in_port)

        # learn a mac address to avoid FLOOD next time.
        self.mac_to_port[dpid][src] = in_port

        if dst in self.mac_to_port[dpid]:
            out_port = self.mac_to_port[dpid][dst]
        else:
            out_port = ofproto.OFPP_FLOOD
        if out_port == in_port:
            out_port = ofproto.OFPP_IN_PORT
       # print 'output %s' % (out_port)
        my_actions = [parser.OFPActionOutput(out_port)]
        my_actions11 = []
        my_actions01 = []
        my_actions02 = []
        my_actions03 = []
        my_actions04 = []
        my_actions05 = []
        if dst != 'ff:ff:ff:ff:ff:ff':
            if eth2 is None:
                next_hop = route_table.get(dpid).get((src,dst))
                # pop_src = route_table.get(dpid).get((src,dst))
                # pop_dst = route_table.get(dpid).get((dst,src))
                # next_hop = dst
                if next_hop:
                    my_actions01[0:0] = [parser.OFPActionPushPbb(ethertype=0x88E7)]
                    my_actions11[0:0] = [parser.OFPActionSetField(pbb_isid=dst_to_isid[(src,dst)])]
                    my_actions11[1:1] = [parser.OFPActionSetField(eth_dst=next_hop)]
                    my_actions11[2:2] = [parser.OFPActionSetField(eth_src=dpid_to_str[dpid])]
                    my_actions11[3:3] = [parser.OFPActionOutput(out_port)]

                    my_actions04[0:0] = [parser.OFPActionPopPbb()]
                    my_actions04[1:1] = [parser.OFPActionSetField(eth_dst=src)]
                    my_actions04[2:2] = [parser.OFPActionSetField(eth_src=dst)]
                    my_actions04[3:3] = [parser.OFPActionOutput(in_port)]
                    # print out_port
                   # print 'pbb_isid:%s dst:%s next_hop:%s' % (dst_to_isid[dst], dst, next_hop)

                else:
                    print "can't find correct mac of next_hop111"
                    # my_actions[0:0] = [parser.OFPActionSetField(eth_src=src)]
                    # my_actions[0:0] = [parser.OFPActionSetField(eth_dst=dst)]
            else:
                if eth1.dst != dpid_to_str[dpid]:
                    my_actions = []
                    print dpid
                    pass
                else:
                    next_hop = route_table.get(dpid).get((src,dst))
                    print 'src:%s dst:%s next_hop:%s' % (src, dst, next_hop)
                    # next_hop = dst
                    if next_hop:
                        if next_hop != dpid_to_str[dpid]:
                            pop_src = eth1.src
                            pop_dst = dpid_to_str[dpid]

                            my_actions02[0:0] = [parser.OFPActionSetField(eth_dst=next_hop)]
                            my_actions02[1:1] = [parser.OFPActionSetField(eth_src=dpid_to_str[dpid])]
                            my_actions02[2:2] = [parser.OFPActionOutput(out_port)]

                            my_actions05[0:0] = [parser.OFPActionPopPbb()]
                            my_actions05[1:1] = [parser.OFPActionSetField(eth_dst=str_to_hostmac[eth1.dst])]
                            my_actions05[2:2] = [parser.OFPActionSetField(eth_src=str_to_hostmac[eth1.src])]
                            my_actions05[3:3] = [parser.OFPActionOutput(1)]



                        else:
                            my_actions03[0:0] = [parser.OFPActionPopPbb()]
                            my_actions03[1:1] = [parser.OFPActionSetField(eth_dst=dst)]
                            my_actions03[2:2] = [parser.OFPActionSetField(eth_src=src)]
                            my_actions03[3:3] = [parser.OFPActionOutput(out_port)]
                    else:
                        print "can't find correct mac of next_hop"


        # install a flow to avoid packet_in next time
        if out_port != ofproto.OFPP_FLOOD:
            # if pkt.get_protocols(arp.arp()):
            #     arp1 = pkt.get_protocols(arp.arp())[0]
            #     match = parser.OFPMatch(in_port=in_port, eth_dst=next_dst, eth_src=src, eth_type=ether_types.ETH_TYPE_ARP, arp_spa=arp1.src_ip)
            # elif pkt.get_protocols(ipv4.ipv4()):
            #     ip1 = pkt.get_protocols(ipv4.ipv4())[0]
            #     match = parser.OFPMatch(in_port=in_port, eth_dst=next_dst, eth_src=src, eth_type=ether_types.ETH_TYPE_IP, ipv4_src=ip1.src)
            # else:
            #out_port
            # if eth2 is None:
            match1 = parser.OFPMatch(in_port=in_port, eth_dst=next_dst, eth_src=eth1.src)
            match2 = parser.OFPMatch(in_port=in_port, eth_dst=next_dst, eth_src=eth1.src, eth_type=0x88E7)
            match3 = parser.OFPMatch(in_port=in_port, eth_dst=next_dst, eth_src=eth1.src, eth_type=0x88E7,
                                     pbb_isid=dst_to_isid[(src,dst)])
            match4 = parser.OFPMatch(in_port=out_port, eth_dst=pop_dst, eth_src=pop_src, eth_type=0x88E7,
                                     pbb_isid=dst_to_isid[(dst, src)])


            if msg.buffer_id != ofproto.OFP_NO_BUFFER:
                if len(my_actions05) != 0:
                    match5 = parser.OFPMatch(in_port=in_port, eth_dst=pop_dst, eth_src=pop_src, eth_type=0x88E7,
                                             pbb_isid=dst_to_isid[(str_to_hostmac[eth1.src], str_to_hostmac[eth1.dst])])
                    self.add_flow(datapath=datapath, buffer_id=msg.buffer_id, priority=3, match=match5, actions=my_actions05)
                if len(my_actions04) != 0:
                    self.add_flow(datapath=datapath, buffer_id=msg.buffer_id, priority=3, match=match4, actions=my_actions04)
                if len(my_actions03) != 0:
                    self.add_flow(datapath=datapath, buffer_id=msg.buffer_id, priority=3, match=match3, actions=my_actions03)
                if len(my_actions02) != 0:
                    self.add_flow(datapath=datapath, buffer_id=msg.buffer_id, priority=2, match=match2, actions=my_actions02)
                if len(my_actions01) != 0:
                    self.add_flow1(datapath=datapath, buffer_id=msg.buffer_id, priority=1, match=match1, actions=my_actions01)
                if len(my_actions11) != 0:
                    self.add_flow(datapath=datapath, buffer_id=msg.buffer_id, priority=1, match=match2, table_id=1, actions=my_actions11)
                return
            else:
                if len(my_actions03) != 0:
                    self.add_flow(datapath, 3, match3, my_actions03)
                if len(my_actions02) != 0:
                    self.add_flow(datapath, 2, match2, my_actions02)
                if len(my_actions01) != 0:
                    self.add_flow1(datapath, 1, match1, my_actions01)
                if len(my_actions11) != 0:
                    self.add_flow(datapath, 1, match2, my_actions11, 1)

            # match1 = parser.OFPMatch(in_port=in_port, eth_dst=next_dst, eth_src=eth1.src, eth_type=0x88E7, pbb_isid=dpid_to_isid[dpid])
            # if msg.buffer_id != ofproto.OFP_NO_BUFFER:
            #     self.add_flow(datapath, 2, match1, my_actions, msg.buffer_id)
            #     return
            # else:
            #     self.add_flow(datapath, 2, match1, my_actions)
            #
            # #
            # match = parser.OFPMatch(in_port=in_port, eth_dst=next_dst, eth_src=eth1.src)
            # #print 'my_actions:%s, match:%s ' % (my_actions,match)
            # # verify if we have a valid buffer_id, if yes avoid to send both
            # # flow_mod & packet_out
            # if msg.buffer_id != ofproto.OFP_NO_BUFFER:
            #     self.add_flow(datapath, 1, match, my_actions, msg.buffer_id)
            #     return
            # else:
            #     self.add_flow(datapath, 1, match, my_actions)


        data = None
        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
            data = msg.data

        out = parser.OFPPacketOut(datapath=datapath, buffer_id=msg.buffer_id,
                                  in_port=in_port, actions=my_actions, data=data)
        datapath.send_msg(out)
