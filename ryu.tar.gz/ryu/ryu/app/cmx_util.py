# coding=utf-8
import os
import re
import json

from time import sleep
import threading
import os

import subprocess

from mininet.node import RemoteController
from mn_wifi.mobility import mobility as mob
from mn_wifi.module import module
from mn_wifi.node import UserAP, Node_wifi, AccessPoint, AP, Station
from mn_wifi.link import wmediumd, wirelessLink, spec_prob_link, \
    set_error_prob, set_snr, start_wmediumd, mesh, IntfWireless, physicalMesh, adhoc, ITSLink, wifiDirectLink, \
    physicalWifiDirectLink, _4address, TCWirelessLink
from mn_wifi.net import Mininet_wifi
from mn_wifi.propagationModels import GetSignalRange, propagationModel
from mn_wifi.sixLoWPAN.link import sixLoWPANLink
from mn_wifi.wmediumdConnector import interference, wmediumd_mode, w_cst, DynamicWmediumdIntfRef, error_prob, w_pos, \
    w_txpower
from mininet.link import Link, Intf, TCLink, TCULink
from mininet.moduledeps import moduleDeps, pathCheck, TUN
from six import string_types
from collections import defaultdict
from threading import Lock
import re

class MyController(RemoteController, Node_wifi):
    def __init__(self, name, ip='127.0.0.1',
                 port=None, **kwargs):
        RemoteController.__init__(self, name, ip=ip, port=port, **kwargs)
        self.wlanports = -1  # dict of wlan interfaces to port numbers
        self.func = []
        self.isStationary = True

    def getRange(self, intf=None, noiseLevel=0):
        "Get the Signal Range"
        interference_enabled = False
        if wmediumd_mode.mode == w_cst.INTERFERENCE_MODE:
            interference_enabled = True
        wlan = self.get_wlan(intf)
        if noiseLevel != 0:
            GetSignalRange.NOISE_LEVEL = noiseLevel
        value = GetSignalRange(self, wlan, interference_enabled)

        return int(value.dist)


class MyUserAP(UserAP):
    def dpctl(self, *args):
        "Run dpctl command"
        listenAddr = None
        if not self.listenPort:
            listenAddr = 'unix:/tmp/%s.listen' % self.name
        else:
            listenAddr = 'tcp:127.0.0.1:%i' % self.listenPort
        return self.cmd('dpctl ' + listenAddr + ' ' + ' '.join(args))

    def start(self, controllers, controller_ip):
        """Start OpenFlow reference user datapath.
           Log to /tmp/sN-{ofd,ofp}.log.
           controllers: list of controller objects
           controller_ip: the ip you config for the interface
           of controller (example: c1-mp1:192.168.0.1)
           """
        # Add controllers
        clist = ','.join(['tcp:%s:%d' % (controller_ip, c.port)
                          for c in controllers])
        ofdlog = '/tmp/' + self.name + '-ofd.log'
        ofplog = '/tmp/' + self.name + '-ofp.log'
        intfs = [str(i) for i in self.intfList() if not i.IP()]
        if self.name + '-mp2' in intfs:
            intfs.remove(self.name + '-mp2')
        self.cmd('ofdatapath -i ' + ','.join(intfs) +
                 ' punix:/tmp/' + self.name + ' -d %s ' % self.dpid +
                 self.dpopts +
                 ' 1> ' + ofdlog + ' 2> ' + ofdlog + ' &')
        self.cmd('ofprotocol ' + self.opts +
                 ' unix:/tmp/' + self.name + ' ' + clist + ' 1> ' + ofplog + ' 2>' + ofplog + ' &')


class MyNet(Mininet_wifi):
    """
    def build(self):
        "Build mininet-wifi."
        if self.topo:
            self.buildFromWirelessTopo(self.topo)
            if self.init_plot or self.init_plot3d:
                max_z = 0
                if self.init_plot3d:
                    max_z = len(self.stations) * 100
                self.plotGraph(max_x=(len(self.stations) * 100),
                               max_y=(len(self.stations) * 100),
                               max_z=max_z)
        else:
            if not mob.stations:
                for node in self.stations:
                    if 'position' in node.params:
                        mob.stations.append(node)

        if (self.configure4addr or self.configureWiFiDirect
            or self.wmediumd_mode == error_prob) and self.link == wmediumd:
            wmediumd(self.fading_coefficient, self.noise_threshold,
                       self.stations, self.aps, self.cars, propagationModel,
                       self.wmediumdMac)
            for sta in self.stations:
                if self.wmediumd_mode != error_prob:
                    sta.set_pos_wmediumd(sta.params['position'])
            for sta in self.stations:
                if sta in self.aps:
                    self.stations.remove(sta)

        if self.inNamespace:
            self.configureControlNetwork()
        info('*** Configuring nodes\n')
        self.configHosts()
        if self.xterms:
            self.startTerms()
        if self.autoStaticArp:
            self.staticArp()

        nodes = self.stations
        for node in nodes:
            for wlan in range(0, len(node.params['wlan'])):
                if not isinstance(node, AP) and node.func[0] != 'ap' and \
                        node.func[wlan] != 'mesh' and \
                        node.func[wlan] != 'adhoc' and \
                        node.func[wlan] != 'wifiDirect':
                    if isinstance(node, Station):
                        node.params['range'][wlan] = \
                            int(node.params['range'][wlan]) / 5

        # if self.allAutoAssociation:
        #     if self.autoAssociation and not self.configureWiFiDirect:
        #         self.auto_association()
        if self.mob_param:
            if 'model' in self.mob_param or self.isVanet or self.nroads != 0:
                self.mob_param['nodes'] = self.getMobileNodes()
                self.start_mobility(**self.mob_param)
            else:
                self.mob_param['plotNodes'] = self.plot_nodes()
                mob.stop(**self.mob_param)
        else:
            if self.DRAW and not self.isReplaying:
                plotNodes = self.plot_nodes()
                self.plotCheck(plotNodes)
        self.built = True
    """

    def configureWmediumd(self):
        """Configure Wmediumd"""
        if self.autoSetPositions:
            self.wmediumd_mode = interference
        self.wmediumd_mode()
        if self.wmediumd_mode == interference:
            mob.wmediumd_mode = 3
        else:
            mob.wmediumd_mode = 1
        if not self.configureWiFiDirect and not self.configure4addr and \
                self.wmediumd_mode != error_prob:
            MyWmediumd(self.fading_coefficient, self.noise_threshold,
                       self.stations, self.aps, self.cars, self.controllers, propagationModel,
                       self.wmediumdMac)

    def configureWifiNodes(self):
        """Configure WiFi Nodes"""
        if not self.ppm_is_set:
            self.setPropagationModel()
        params = {}
        if self.ifb:
            wirelessLink.ifb = True
            params['ifb'] = self.ifb
        if self.docker:
            params['docker'] = self.docker
            params['container'] = self.container
            params['ssh_user'] = self.ssh_user
        nodes = self.stations + self.aps + self.cars + self.controllers
        module(nodes, self.n_radios, self.alt_module, **params)
        self.configureWirelessLink()
        self.createVirtualIfaces(self.stations)
        AccessPoint(self.aps + self.controllers, self.driver, self.link)

        if self.link == wmediumd:
            self.configureWmediumd()

        setParam = True
        if self.wmediumd_mode == interference and not self.isVanet:
            setParam = False

        for node in nodes:
            for wlan in range(0, len(node.params['wlan'])):
                if int(node.params['range'][wlan]) == 0:
                    intf = node.params['wlan'][wlan]
                    node.params['range'][wlan] = node.getRange(intf=intf)
                else:
                    if 'model' not in node.params:
                        node.params['txpower'][wlan] = \
                            node.get_txpower_prop_model(wlan)
                if not self.configure4addr and not self.configureWiFiDirect:
                    node.setTxPower(node.params['txpower'][wlan],
                                    intf=node.params['wlan'][wlan],
                                    setParam=setParam)
                    node.setAntennaGain(node.params['antennaGain'][wlan],
                                        intf=node.params['wlan'][wlan],
                                        setParam=setParam)

        return self.stations, self.aps

    def addLink(self, node1, node2=None, port1=None, port2=None,
                cls=None, **params):
        """"Add a link from node1 to node2
            node1: source node (or name)
            node2: dest node (or name)
            port1: source port (optional)
            port2: dest port (optional)
            cls: link class (optional)
            params: additional link params (optional)
            returns: link object"""

        # Accept node objects or names
        node1 = node1 if not isinstance(node1, string_types) else self[node1]
        node2 = node2 if not isinstance(node2, string_types) else self[node2]
        options = dict(params)

        self.conn.setdefault('src', [])
        self.conn.setdefault('dst', [])
        self.conn.setdefault('ls', [])

        cls = self.link if cls is None else cls

        if cls == mesh or cls == physicalMesh:
            isAP=False
            if isinstance(node1, AP):
                isAP=True
            cls(node=node1, isAP=isAP, **params)
        elif cls == Mymesh:
            isAP = False
            if isinstance(node1, AP):
                isAP = True
            cls(node=node1, isAP=isAP, **params)
        elif cls == adhoc:
            cls(node=node1, link=self.link, **params)
        elif cls == ITSLink:
            cls(node=node1, link=self.link, **params)
        elif cls == wifiDirectLink or cls == physicalWifiDirectLink:
            link = cls(node=node1, port=port1, **params)
            return link
        elif cls == sixLoWPANLink:
            link = cls(node=node1, port=port1, **params)
            self.links.append(link)
            return link
        elif cls == _4address:
            if 'position' in node1.params and 'position' in node2.params:
                self.conn['src'].append(node1)
                self.conn['dst'].append(node2)
                self.conn['ls'].append('--')

            if node1 not in self.aps:
                self.aps.append(node1)
            elif node2 not in self.aps:
                self.aps.append(node2)

            if self.wmediumd_mode == interference:
                link = cls(node1, node2, port1, port2)
                self.links.append(link)
                return link
            else:
                dist = node1.get_distance_to(node2)
                if dist <= node1.params['range'][0]:
                    link = cls(node1, node2)
                    self.links.append(link)
                    return link
        elif ((node1 in (self.stations or self.cars) and node2 in self.aps)
              or (node2 in (self.stations or self.cars) and node1 in self.aps)) and \
                        'link' not in options:
            self.infraAssociation(node1, node2, port1, port2, cls, **params)
        elif 'wifi' in params:
            self.infraAssociation(node1, node2, port1, port2, cls, **params)
        else:
            if 'link' in options:
                options.pop('link', None)

            if 'position' in node1.params and 'position' in node2.params:
                self.conn['src'].append(node1)
                self.conn['dst'].append(node2)
                self.conn['ls'].append('-')
            # Port is optional
            if port1 is not None:
                options.setdefault('port1', port1)
            if port2 is not None:
                options.setdefault('port2', port2)

            # Set default MAC - this should probably be in Link
            options.setdefault('addr1', self.randMac())
            options.setdefault('addr2', self.randMac())

            if not cls or cls == wmediumd or cls == TCWirelessLink:
                cls = TCLink
            if self.disable_tcp_checksum:
                cls = TCULink

            cls = self.link if cls is None else cls
            link = cls(node1, node2, **options)
            self.links.append(link)
            return link

    def generatePositionFile(self):
        print "\n*** writing file..."
        position_dict = defaultdict(dict)
        for ap in self.aps:
            position_dict[ap.dpid]['position'] = ap.params['position']
            position_dict[ap.dpid]['range'] = ap.params['range'][0]
        lock = Lock()
        lock.acquire()
        with open("/home/sdn/mininet-wifi/examples/test_position.json", 'w') as f:
            json.dump(position_dict, f)
        lock.release()

        print "*** writing file complete"

    def generateLinkJsonFile(self):
        print "\n***writing file..."
        lock = Lock()
        lock.acquire()
        for ap in self.aps:
            link_dict = {}
            link_dict["MAC"] = ap.params["mac"][0]
            neighbour = ap.cmd("iw dev %s-mp1 station dump" % ap.name)
            neighbour = re.findall(r'[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}', neighbour)
            link_dict["Neighbour"] = neighbour
            with open("/home/sdn/mininet-wifi/examples/neighbour/%s.json" % ap.name, 'w') as f:
                json.dump(link_dict, f)
        lock.release()
        print "\n*** writing file complete"

    def generateLinkTxtFile(self):
        print "\n***writing file..."

        lock = Lock()
        lock.acquire()
        for ap in self.aps:
            neighbourID = []  # ap1 -> 1  ap2 -> 2
            neighbour = ap.cmd("iw dev %s-mp1 station dump" % ap.name)
            neighbour = re.findall(r'[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}', neighbour)
            for n in neighbour:
                neighbourID.append(MacToNid(n))
            content = ' '.join(neighbourID) + '\n'
            with open("/home/sdn/mininet-wifi/examples/neighbour/%s.txt" % ap.name, 'w') as f:
                f.writelines(content)
        lock.release()
        print "\n*** writing file complete"


def MacToNid(mac):
    Nid = 0
    temp = mac.split(':')[-3:-1]
    Nid += int(temp[0],16) * 256
    Nid += int(temp[1],16)
    Nid = (Nid+2) / 2
    return str(Nid)




class My_set_interference(object):

    def __init__(self):
        self.interference()

    @classmethod
    def interference(cls):
        'configure interference model'
        for node in MyWmediumd.nodes:
            if 'position' not in node.params:
                posX = 0
                posY = 0
                posZ = 0
            else:
                posX = float(node.params['position'][0])
                posY = float(node.params['position'][1])
                posZ = float(node.params['position'][2])
            node.lastpos = [posX, posY, posZ]

            for wlan in range(0, len(node.params['wlan'])):
                if wlan >= 1:
                    posX+=0.1
                if wlan < len(node.params['mac']):
                    wmediumd.positions.append(w_pos(node.wmIface[wlan],
                                                    [posX, posY, posZ]))
                    wmediumd.txpowers.append(w_txpower(
                        node.wmIface[wlan], float(node.params['txpower'][wlan])))


class MyWmediumd(wmediumd):
    "Wmediumd Class"
    wlinks = []
    links = []
    txpowers = []
    positions = []
    nodes = []
    def __init__(self, fading_coefficient, noise_threshold, stations,
                 aps, cars, controllers, propagation_model, maclist=None):

        self.configureWmediumd(fading_coefficient, noise_threshold, stations,
                               aps, cars, controllers, propagation_model, maclist)

    @classmethod
    def configureWmediumd(cls, fading_coefficient, noise_threshold, stations,
                          aps, cars, controllers, propagation_model, maclist):
        """Configure wmediumd"""
        intfrefs = []
        isnodeaps = []
        fading_coefficient = fading_coefficient
        noise_threshold = noise_threshold

        cls.nodes = stations + aps + cars + controllers
        for node in cls.nodes:
            node.wmIface = []
            for wlan in range(0, len(node.params['wlan'])):
                if wlan < len(node.params['mac']):
                    node.wmIface.append(wlan)
                    node.wmIface[wlan] = DynamicWmediumdIntfRef(node, intf=wlan)
                    intfrefs.append(node.wmIface[wlan])
                    if (node.func[wlan] == 'ap'
                            or (node in aps and (node.func[wlan] is not 'client'
                                                 and node.func[wlan] is not 'adhoc'))):
                        isnodeaps.append(1)
                    elif isinstance(node, RemoteController):
                        isnodeaps.append(1)
                    else:
                        isnodeaps.append(0)
            for n in maclist:
                for key in n:
                    if key == node:
                        key.wmIface.append(DynamicWmediumdIntfRef(key, intf=len(key.wmIface)))
                        key.func.append('none')
                        key.params['wlan'].append(n[key][1])
                        key.params['mac'].append(n[key][0])
                        key.params['range'].append(0)
                        key.params['freq'].append(key.params['freq'][0])
                        key.params['antennaGain'].append(0)
                        key.params['txpower'].append(14)
                        intfrefs.append(key.wmIface[len(key.wmIface) - 1])
                        isnodeaps.append(0)

        if wmediumd_mode.mode == w_cst.INTERFERENCE_MODE:
            My_set_interference()
        elif wmediumd_mode.mode == w_cst.SPECPROB_MODE:
            spec_prob_link()
        elif wmediumd_mode.mode == w_cst.ERRPROB_MODE:
            set_error_prob()
        else:
            set_snr()
        start_wmediumd(intfrefs, wmediumd.links, wmediumd.positions,
                       fading_coefficient, noise_threshold,
                       wmediumd.txpowers, isnodeaps, propagation_model,
                       maclist)


class ssid_matrix:
    def __init__(self, nodes=50):
        """
        生成一个默认50*50的对称矩阵，用于查询ssid
        :param nodes:默认50个节点
        """
        count = 1
        self.matrix = []

        # 生成一个上三角矩阵
        for i in range(nodes):
            raw = []  # 每一行都是一个列表
            for j in range(i + 1):
                raw.append(0)
            raw.extend(range(count, count + nodes - i - 1))
            self.matrix.append(raw)
            count = count + nodes - i - 1

        # 将上三角矩阵变为对称矩阵
        for i in range(nodes):
            for j in range(i + 1, nodes):
                self.matrix[j][i] = self.matrix[i][j]

    def show_matrix(self):
        """
        将整个矩阵打印出来
        """
        for i in range(len(self.matrix)):
            print self.matrix[i]

    def find_ssid(self, x, y):
        """
        返回一串字符串，该字符串代表mesh-ssid
        """
        return "mesh-ssid%s" % self.matrix[x][y]

class Mymesh(mesh):
    """
    TODO: There is something wrong with mode monitor, cannot ping one another even in the same ssid
    """
    def set_mode_monitor(self):
        self.cmd("iwconfig %s mode monitor" % self.name)

    def set_mesh_params(self, node):
        node.cmd("iw dev %s set mesh_param mesh_auto_open_plinks 0" % self.name)

    def setMeshIface(self, node, ssid=None, **params):
        wlan = node.params['wlan'].index(self.name)
        intf = node.params['wlan'][wlan]
        if node.func[wlan] == 'adhoc':
            self.setType('managed')
        self.name = '%s-mp%s' % (node, node.params['wlan'][wlan][-1:])
        if node.func[wlan] == 'mesh' and 'phyap' in params:
            self.name = '%s-mp%s' % (node, wlan + 1)

        self.setType('mp', node.params['wlan'][wlan])
        # self.set_mode_monitor()
        self.setMAC(node.params['mac'][wlan])
        node.cmd('ip link set %s down' % intf)
        self.rename(node, self, self.name)
        node.params['wlan'][wlan] = self.name

        if 'channel' in params:
            IntfWireless.setChannel(node, params['channel'], intf=self.name)

        if 'mode' in params and (params['mode'] == 'a'
                                 or params['mode'] == 'ac'):
            node.pexec('iw reg set US')

        intf = node.params['wlan'][wlan]
        if 'freq' in params:
            freq = params['freq']
            self.setFreq(freq, intf)
            self.params['freq'][wlan] = freq

        if 'ip' in node.params:
            node.cmd('ip addr add %s dev %s' % (node.params['ip'][wlan],
                                                self.name))
        else:
            self.name = intf
        self.ipLink('up')

        self.configureMesh(node, wlan, **params)

    def associate(self, node, wlan, **params):
        "Performs Mesh Association"
        name = node.params['wlan'][wlan]
        ssid = node.params['ssid'][wlan]
        freq = self.get_freq(node.params['freq'][wlan])
        ht_cap = ''
        if 'ht_cap' in params:
            ht_cap = params['ht_cap']
        self.join('mesh', ssid, freq, ht_cap, name)
        self.set_mesh_params(node)

class UserSta(Station):
    "User-space AP."

    dpidLen = 12

    def __init__(self, name, listenPort=None, dpid=None, opts='', dpopts='--no-slicing', **kwargs):
        """Init.
           name: name for the switch
           dpopts: additional arguments to ofdatapath (--no-slicing)"""
        Station.__init__(self, name, **kwargs)
        self.listenPort = listenPort
        self.opts = opts
        self.dpid = self.defaultDpid(dpid)
        pathCheck('ofdatapath', 'ofprotocol',
                  moduleName='the OpenFlow reference user switch' +
                  '(openflow.org)')
        if self.listenPort:
            self.opts += ' --listen=ptcp:%i ' % self.listenPort
        else:
            self.opts += ' --listen=punix:/tmp/%s.listen' % self.name
        self.dpopts = dpopts

    @classmethod
    def setup(cls):
        "Ensure any dependencies are loaded; if not, try to load them."
        if not os.path.exists('/dev/net/tun'):
            moduleDeps(add=TUN)

    def dpctl(self, *args):
        "Run dpctl command"
        listenAddr = None
        if not self.listenPort:
            listenAddr = 'unix:/tmp/%s.listen' % self.name
        else:
            listenAddr = 'tcp:127.0.0.1:%i' % self.listenPort
        return self.cmd('dpctl ' + listenAddr + ' ' + ' '.join(args))

    def connected(self):
        "Is the ap connected to a controller?"
        status = self.dpctl('status')
        return ('remote.is-connected=true' in status and
                'local.is-connected=true' in status)

    @staticmethod
    def TCReapply(intf):
        """Unfortunately user switch and Mininet are fighting
           over tc queuing disciplines. To resolve the conflict,
           we re-create the user switch's configuration, but as a
           leaf of the TCIntf-created configuration."""
        if isinstance(intf, TCWirelessLink):
            ifspeed = 10000000000  # 10 Gbps
            minspeed = ifspeed * 0.001

            res = intf.config(**intf.params)

            if res is None:  # link may not have TC parameters
                return

            # Re-add qdisc, root, and default classes user switch created, but
            # with new parent, as setup by Mininet's TCIntf
            parent = res['parent']
            intf.tc("%s qdisc add dev %s " + parent +
                    " handle 1: htb default 0xfffe")
            intf.tc("%s class add dev %s classid 1:0xffff parent 1: htb rate "
                    + str(ifspeed))
            intf.tc("%s class add dev %s classid 1:0xfffe parent 1:0xffff " +
                    "htb rate " + str(minspeed) + " ceil " + str(ifspeed))

    def start(self, controllers, controller_ip):
        """Start OpenFlow reference user datapath.
           Log to /tmp/sN-{ofd,ofp}.log.
           controllers: list of controller objects
           controller_ip: the ip you config for the interface
           of controller (example: c1-mp1:192.168.0.1)
           """
        # Add controllers
        clist = ','.join(['tcp:%s:%d' % (controller_ip, c.port)
                          for c in controllers])
        ofdlog = '/tmp/' + self.name + '-ofd.log'
        ofplog = '/tmp/' + self.name + '-ofp.log'
        intfs = [str(i) for i in self.intfList()]
        if self.name + '-mp1' in intfs:
            intfs.remove(self.name + '-mp1')
        self.cmd('ofdatapath -i ' + ','.join(intfs) +
                 ' punix:/tmp/' + self.name + ' -d %s ' % self.dpid +
                 self.dpopts +
                 ' 1> ' + ofdlog + ' 2> ' + ofdlog + ' &')
        self.cmd('ofprotocol ' + self.opts +
                 ' unix:/tmp/' + self.name + ' ' + clist + ' 1> ' + ofplog + ' 2>' + ofplog + ' &')

    def stop(self, deleteIntfs=True):
        """Stop OpenFlow reference user datapath.
           deleteIntfs: delete interfaces? (True)"""
        # self.cmd('kill %ofdatapath')
        # self.cmd('kill %ofprotocol')
        # super(UserAP, self).stop(deleteIntfs)

    def setManagedIface(self, iface):
        wlan = self.params['wlan'].index(iface)
        if self.func[wlan] == 'mesh':
            self.cmd('iw dev %s del' % self.params['wlan'][wlan])
            iface = '%s-wlan%s' % (self, wlan)
            self.params['wlan'][wlan] = iface
        self.cmd('iw dev %s set type managed' % (self.params['wlan'][wlan]))

    def defaultDpid(self, dpid=None):
        "Return correctly formatted dpid from dpid or switch name (s1 -> 1)"
        if dpid:
            # Remove any colons and make sure it's a good hex number

            dpid = dpid.translate(str.maketrans('', '', ':'))
            assert len(dpid) <= self.dpidLen and int(dpid, 16) >= 0
            return '0' * (self.dpidLen - len(dpid)) + dpid
        else:
            # Use hex of the first number in the switch name
            nums = re.findall(r'\d+', self.name)
            if nums:
                dpid = hex(int(nums[ 0 ]))[ 2: ]
            else:
                raise Exception('Unable to derive default datapath ID - '
                                'please either specify a dpid or use a '
                                'canonical ap name such as ap23.')
            return '1' + '0' * (self.dpidLen -1 - len(dpid)) + dpid

def setThreadToSetParams(aps):
    threads = []
    t1 = threading.Thread(target=setParamsFromFileSub,args=(aps,))
    threads.append(t1)
    t1.setDaemon(True)
    # t2 = threading.Thread(target=update_timing,args=(aps,))
    # threads.append(t2)
    # t2.setDaemon(True)
    try:
        for t in threads:
            t.start()
    except:
        print ("Error: unable to start thread")


def setParamsFromFileSub(aps):
    # 判断管道文件是否存在，若不存在则创建
    if not os.path.exists("/home/sdn/test/fifo"):
        os.system('mkfifo /home/sdn/test/fifo')
    # print "Subprocess"
    p = subprocess.Popen("/home/sdn/test/read_fifo.sh", shell=False, stdout=subprocess.PIPE)
    for line in iter(p.stdout.readline, ''):
        print line.rstrip()
        # info_split = line.strip()
        info_split = line.split(" ")
        # print info_split
        # wlan_name = "ap%s-mp%s" % (info_split[0], info_split[1])
        # # 更改对应参数
        # for j in range(2, len(info_split)):
        #     var = info_split[j].split(":")
        #     if var[0] == 'txpower':
        #         aps[(int)(info_split[0]) - 1].setTxPower((int)(var[1]), wlan_name)
        #     elif var[0] == 'freq':
        #         pass
        #     elif var[0] == 'range':
        #         pass
        #     else:
        #         pass
        print '*' * 10

