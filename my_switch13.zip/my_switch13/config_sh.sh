#./boot.sh
./configure LDFLAGS='-pthread'
make
make install
