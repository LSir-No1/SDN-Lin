简易C-S架构下多控制器通信，根据neighbours_find消息各控制器收集局部网络拓扑信息（包含拓扑连接、RSSI值），统一上报至服务器端，由服务器整合全网拓扑信息。
-------------------------------------------------

运行前请替换掉之前的client_ryu_1.py，并再编译一下ryu

1.运行server文件

    ./server_ryu_2.py

2.运行两个控制器文件，第一个控制器默认监听端口6633

    ryu-manager --observe --ofp-tcp-listen-port 6633 myRyu_new_5_lyz.py
    ryu-manager --observe --ofp-tcp-listen-port 6653 myRyu_new_5_lyz.py

3.运行拓扑文件

    ./topo_QoS.py



此版改动：

​		ryu控制器脚本中添加pcp,vlan_id等字段，用于区别服务等级；

​		将拓扑改为环形：

​		将client_ryu_1.py中第70行改为message = self.socket.recv(4096)，否则控制器收到来自服务器的信息会不完整。