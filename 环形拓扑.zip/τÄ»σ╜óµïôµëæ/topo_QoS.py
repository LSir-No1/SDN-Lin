#!/usr/bin/python
# coding=utf-8

"""
simple control net:
                          server
                       /         \
                      c1         c2
                       \          \
                        ap1--ap2--ap3--ap4
                       /     /    /    /
                      h1    h2   h3   h4


                          server
                       /         \
                      c1         c2
                       \          \
                    h1--ap1---------ap3--h3
                         ｜          ｜
                    h2--ap2---------ap4--h4
"""

from mininet.link import TCULink
from mininet.log import setLogLevel, info
from mininet.node import Controller, RemoteController
from cmx_util import MyNet, MyController, MyUserAP, ssid_matrix, Mymesh
from mn_wifi.cli import CLI_wifi
from mn_wifi.link import wmediumd, mesh, adhoc
from mn_wifi.wmediumdConnector import interference
from time import sleep


def topology():
    """"Create a network."""
    """add something"""
    net = MyNet(link=wmediumd, wmediumd_mode=interference, controller=MyController)

    info("*** Creating nodes\n")
    c1 = net.addController('c1'
                           , ip='127.0.0.1'
                           , port=6633
                           , cls=RemoteController
                           )
    c2 = net.addController('c2'
                           , ip='127.0.0.1'
                           , port=6653
                           , cls=RemoteController
                           )

    aps = []
    hosts = []
    num_nodes = 4
    for i in range(1, num_nodes+1):
        if i == 1 :
            aps.append(net.addAccessPoint('ap' + str(i), cls=MyUserAP, wlans=2, ssid="," + str(i), inNamespace=True,
                                          position='10,100,0'))
        if i == 2:
            aps.append(net.addAccessPoint('ap' + str(i), cls=MyUserAP, wlans=2, ssid="," + str(i), inNamespace=True,
                                          position='10,160,0'))
        if i == 3 :
            aps.append(net.addAccessPoint('ap' + str(i), cls=MyUserAP, wlans=2, ssid="," + str(i), inNamespace=True,
                                          position='60,100,0'))
        if i == 4:
            aps.append(net.addAccessPoint('ap' + str(i), cls=MyUserAP, wlans=2, ssid="," + str(i), inNamespace=True,
                                          position='60,160,0'))
        #aps.append(net.addAccessPoint('ap' + str(i), cls=MyUserAP, wlans=2, ssid="," + str(i), inNamespace=True,
                                      #position=str(10 + (i - 1) * 50) + ',100,0'))
        hosts.append(net.addHost('h' + str(i), mac='00:00:00:00:00:0%d' % i))

    net.setPropagationModel(model="logDistance", exp=4)

    defaults = {'listenPort': net.listenPort,
                'inNamespace': False,
                'ssid': net.ssid,
                'channel': net.channel,
                'mode': net.mode,
                'position': '10,100,0'  # the same position as ap1
                }

    defaults2 = {'listenPort': net.listenPort,
                'inNamespace': False,
                'ssid': net.ssid,
                'channel': net.channel,
                'mode': net.mode,
                'position': '60,100,0'  # the same position as ap3
                }

    net.addParameters(c1, False, node_mode='master', **defaults)
    net.addParameters(c2, False, node_mode='master', **defaults2)

    info("*** Configuring wifi nodes\n")
    net.configureWifiNodes()

    info("*** Configuring Links\n")
    # Meshtap是由apN-mp1组成的用于传输Openflow数据包的控制网络
    net.addLink("ap1", intf="ap1-wlan2", cls=mesh, ssid='c1meshtap')
    net.addLink("ap2", intf="ap2-wlan2", cls=mesh, ssid='c1meshtap')

    net.addLink("ap3", intf="ap3-wlan2", cls=mesh, ssid='c2meshtap')
    net.addLink("ap4", intf="ap4-wlan2", cls=mesh, ssid='c2meshtap')

    for i in range(1, num_nodes+1):
        net.addLink("h" + str(i), "ap" + str(i), cls=TCULink)
        # MeshNet是由apN-mp2组成的用于数据传输的无线mesh网络
        net.addLink("ap" + str(i), intf="ap" + str(i) + "-wlan1", cls=mesh, ssid='MeshNet')

    for i in range(1, num_nodes+1):
        ap = net['ap' + str(i)]
        wlan = 'ap%d-wlan1' % i
        ap.nameToIntf[wlan].delete()
        if wlan in ap.nameToIntf:
            ap.delIntf(ap.nameToIntf[wlan])
        wlan = 'ap%d-wlan2' % i
        ap.nameToIntf[wlan].delete()
        if wlan in ap.nameToIntf:
            ap.delIntf(ap.nameToIntf[wlan])

    info("*** Building outband network\n")
    # 为SDN控制器c1添加一个无线端口c1-mp1, 并将其IP地址设置为'192.168.0.1/24'
    net.addLink(c1, cls=mesh, intf='c1-wlan1', ssid='c1meshtap')
    c1.cmd('ifconfig c1-mp1 192.168.0.1/24 up')
    wlan = 'c1-wlan0'
    c1.nameToIntf[wlan].delete()

    # 为SDN控制器c2添加一个无线端口c2-mp1, 并将其IP地址设置为'192.168.1.1/24'
    net.addLink(c2, cls=mesh, intf='c2-wlan1', ssid='c2meshtap')
    c2.cmd('ifconfig c2-mp1 192.168.1.1/24 up')
    wlan = 'c2-wlan0'
    c2.nameToIntf[wlan].delete()

    net.plotGraph(max_x=220, max_y=300)

    info("*** Building network\n")
    net.build()

    aps[0].cmd('ifconfig ap1-mp2 192.168.0.2/24 up')
    aps[1].cmd('ifconfig ap2-mp2 192.168.0.3/24 up')

    aps[2].cmd('ifconfig ap3-mp2 192.168.1.2/24 up')
    aps[3].cmd('ifconfig ap4-mp2 192.168.1.3/24 up')

    aps[0].start([c1], '192.168.0.1')
    aps[1].start([c1], '192.168.0.1')

    aps[2].start([c2], '192.168.1.1')
    aps[3].start([c2], '192.168.1.1')

    info("*** Starting network\n")
    c1.start()
    c2.start()

    sleep(1)


    info("*** Running CLI\n")
    CLI_wifi(net)

    info("*** Stopping network\n")
    net.stop()


if __name__ == '__main__':
    setLogLevel('info')
    topology()
